//import './App.css';

function App() {
  return (
    <div>
      <h1>Hello World!</h1>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab eum impedit consectetur placeat. Delectus doloremque quisquam in facere deleniti quia.</p>
    </div>
  );
}

export default App;
